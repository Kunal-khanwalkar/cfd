README.txt

Perpetuity is a Story-Driven Text based game where the player takes control of a person who is a drug addict, and how his life goes downhill because of it's influence. The drugs are an integral part of his daily life and it depends on you to help the player lose his drug addiction and get his life back on line. The choices you make in the game will affect your final outcome.
The game is made entirely on C++ and it uses winmm library for Sounds. 
We used the following sites - www.soundbible.com and www.freesound.org to download the sounds used in these games. All the sounds are free to use, come under the Creative Commons license and do not infringe any copyright laws.

This project was created for the Microsoft code.fun.do hackathon organised at Manipal Institute of Technology from 18th to 24th of January.

Project Name - Perpetuity
Team Name - Ne0phytes
Members - Manav Agarwal
          Kunal Khanwalkar
          Pratyush Mishra
